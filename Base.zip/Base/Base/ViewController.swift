//
//  ViewController.swift
//  Base
//
//  Created by Oscar Swanros on 4/12/15.
//  Copyright (c) 2015 MobileCoder. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "MobileCoder.mx"
    }
    
}